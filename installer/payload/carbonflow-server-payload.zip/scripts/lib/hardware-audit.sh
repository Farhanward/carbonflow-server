#!/bin/sh

cf_die() {
  echo "ERROR: $*" >&2
  exit 1
}

cf_disk_name() {
  basename "$1"
}

cf_disk_rota() {
  disk_name="$(cf_disk_name "$1")"
  lsblk -dn -o NAME,ROTA | awk -v d="$disk_name" '$1 == d { print $2; found=1 } END { if (!found) exit 1 }'
}

cf_disk_type() {
  rota="$(cf_disk_rota "$1")"
  if [ "$rota" = "0" ]; then
    echo "ssd"
  else
    echo "hdd"
  fi
}

cf_cpu_cores() {
  nproc 2>/dev/null || grep -c '^processor' /proc/cpuinfo 2>/dev/null || echo 1
}

cf_cpu_model() {
  awk -F: '/model name/ { sub(/^[ \t]+/, "", $2); print $2; exit }' /proc/cpuinfo 2>/dev/null || echo unknown
}

cf_ram_mb() {
  awk '/MemTotal/ { print int($2 / 1024) }' /proc/meminfo
}

cf_zram_mb_for_ram() {
  ram_mb="$1"
  if [ "$ram_mb" -le 4096 ]; then
    echo 16384
  elif [ "$ram_mb" -le 8192 ]; then
    echo 20480
  elif [ "$ram_mb" -le 12288 ]; then
    echo 24576
  else
    echo 27648
  fi
}

cf_partition_suffix() {
  case "$1" in
    *nvme*|*mmcblk*) echo "p" ;;
    *) echo "" ;;
  esac
}

cf_write_hardware_env() {
  target_disk="$1"
  output_file="$2"
  disk_name="$(cf_disk_name "$target_disk")"
  disk_rota="$(cf_disk_rota "$target_disk")"
  disk_type="$(cf_disk_type "$target_disk")"
  cpu_cores="$(cf_cpu_cores)"
  cpu_model="$(cf_cpu_model)"
  ram_mb="$(cf_ram_mb)"
  zram_mb="$(cf_zram_mb_for_ram "$ram_mb")"

  mkdir -p "$(dirname "$output_file")"
  cat > "$output_file" <<EOF
CARBONFLOW_TARGET_DISK="$target_disk"
CARBONFLOW_DISK_NAME="$disk_name"
CARBONFLOW_DISK_ROTA="$disk_rota"
CARBONFLOW_DISK_TYPE="$disk_type"
CARBONFLOW_CPU_CORES="$cpu_cores"
CARBONFLOW_CPU_MODEL="$cpu_model"
CARBONFLOW_RAM_MB="$ram_mb"
CARBONFLOW_ZRAM_MB="$zram_mb"
EOF
}

cf_print_audit() {
  env_file="$1"
  echo "==> CarbonFlow hardware audit"
  sed 's/^/  /' "$env_file"
}
