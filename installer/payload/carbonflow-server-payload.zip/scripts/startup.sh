#!/bin/sh
set -eu

STACK_DIR="/opt/carbonflow/compose"
VAULT_DIR="/vault"
LOG_DIR="$VAULT_DIR/logs"
HARDWARE_ENV="/etc/carbonflow/hardware.env"
RUNTIME_ENV="/etc/carbonflow/runtime.env"
MODEL="${OLLAMA_MODEL:-phi3:mini}"
LOG_FILE="/var/log/carbonflow-startup.log"
DOCKER_DATA_ROOT="${CARBONFLOW_DOCKER_DATA_ROOT:-/var/lib/docker}"
ALLOW_ONLINE_PULL="${CARBONFLOW_ALLOW_ONLINE_PULL:-NO}"
RUNTIME_ZRAM_MB="${CARBONFLOW_ZRAM_MB:-}"
# Offline bundle paths (written by build-offline-bundle.sh)
BUNDLE_READY="/opt/carbonflow/.bundle-ready"
IMAGE_ARCHIVE="/opt/carbonflow/docker-images/carbonflow-compose-images.tar.gz"
MODEL_ARCHIVE="/opt/carbonflow/ollama-models/ollama-models.tar.gz"

mkdir -p /var/log
exec >> "$LOG_FILE" 2>&1
echo "==> CarbonFlow startup started at $(date -Iseconds)"

die() {
  echo "ERROR: $*" >&2
  exit 1
}

env_value() {
  key="$1"
  awk -F= -v k="$key" '$1 == k { sub(/^[^=]*=/, ""); print; found=1 } END { if (!found) print "" }' "$STACK_DIR/.env"
}

set_env_value() {
  key="$1"
  value="$2"
  tmp="$(mktemp)"
  if grep -q "^$key=" "$STACK_DIR/.env"; then
    awk -v k="$key" -v v="$value" 'BEGIN{FS=OFS="="} $1 == k {$0=k "=" v} {print}' "$STACK_DIR/.env" > "$tmp"
  else
    cp "$STACK_DIR/.env" "$tmp"
    printf '%s=%s\n' "$key" "$value" >> "$tmp"
  fi
  cat "$tmp" > "$STACK_DIR/.env"
  rm -f "$tmp"
}

ensure_secret() {
  key="$1"
  current="$(env_value "$key")"
  case "$current" in
    ""|change_me*|replace_with*)
      set_env_value "$key" "$(openssl rand -hex 24)"
      ;;
  esac
}

write_credentials_recovery() {
  recovery_dir="$VAULT_DIR/credentials"
  mail_dir="$VAULT_DIR/mail"
  recovery_file="$recovery_dir/carbonflow-credentials.txt"
  mail_file="$mail_dir/carbonflow-credentials.eml"
  pending_file="$mail_dir/carbonflow-credentials.pending"
  recipient="$(env_value CREDENTIAL_RECOVERY_EMAIL)"
  recipient="${recipient:-far7an.o88@gmail.com}"
  smtp_host="$(env_value SMTP_HOST)"
  smtp_port="$(env_value SMTP_PORT)"
  smtp_tls="$(env_value SMTP_TLS)"
  smtp_user="$(env_value SMTP_USER)"
  smtp_password="$(env_value SMTP_PASSWORD)"
  smtp_from="$(env_value SMTP_FROM)"
  system_email="$(env_value SYSTEM_EMAIL)"
  audit_log="$(env_value EMAIL_AUDIT_LOG)"
  smtp_port="${smtp_port:-587}"
  smtp_tls="${smtp_tls:-YES}"
  system_email="${system_email:-info@carbonflow.care}"
  smtp_host="${smtp_host:-mail.carbonflow.care}"
  smtp_user="${smtp_user:-$system_email}"
  smtp_from="${smtp_from:-CarbonFlow Tech <info@carbonflow.care>}"
  audit_log="${audit_log:-$VAULT_DIR/mail/mail-audit.log}"

  mkdir -p "$recovery_dir" "$mail_dir"
  chmod 700 "$recovery_dir"
  chmod 770 "$mail_dir"

  {
    echo "CarbonFlow Tech credential recovery"
    echo "Generated: $(date -Iseconds)"
    echo
    if [ -f /root/carbonflow-first-login.txt ]; then
      echo "== Server login =="
      cat /root/carbonflow-first-login.txt
      echo
    else
      echo "== Server login =="
      echo "User: carbonadmin"
      echo "Password: see /root/carbonflow-first-login.txt on the server root filesystem"
      echo
    fi
    echo "== Control panel =="
    echo "URL: http://SERVER_LAN_IP:8088"
    echo "User: $(env_value CONTROL_PANEL_USER)"
    echo "Password: $(env_value CONTROL_PANEL_PASSWORD)"
    echo
    echo "== n8n =="
    echo "URL: $(env_value N8N_WEBHOOK_URL)"
    echo "User: $(env_value N8N_BASIC_AUTH_USER)"
    echo "Password: $(env_value N8N_BASIC_AUTH_PASSWORD)"
    echo
    echo "Recovery file: $recovery_file"
  } > "$recovery_file"
  chmod 600 "$recovery_file"

  {
    echo "To: $recipient"
    echo "From: $smtp_from"
    echo "Subject: CarbonFlow deployment credentials"
    echo "Content-Type: text/plain; charset=UTF-8"
    echo
    cat "$recovery_file"
  } > "$mail_file"
  chmod 600 "$mail_file"

  if [ -n "$smtp_host" ]; then
    echo "==> إرسال بيانات الدخول إلى $recipient"
    tls_arg=""
    [ "$smtp_tls" = "NO" ] || tls_arg="--ssl-reqd"
    auth_arg=""
    if [ -n "$smtp_password" ]; then
      auth_arg="--user $smtp_user:$smtp_password"
    fi
    # shellcheck disable=SC2086
    if curl --url "smtp://$smtp_host:$smtp_port" \
      $tls_arg \
      --mail-from "$system_email" \
      --mail-rcpt "$recipient" \
      $auth_arg \
      --upload-file "$mail_file" \
      --max-time 60; then
      date -Iseconds > "$mail_dir/carbonflow-credentials.sent"
      rm -f "$pending_file"
      echo "تم إرسال بيانات الدخول إلى $recipient"
      printf '%s sent credential recovery to %s via %s:%s\n' "$(date -Iseconds)" "$recipient" "$smtp_host" "$smtp_port" >> "$audit_log"
    else
      cp "$mail_file" "$pending_file"
      echo "تعذر إرسال البريد الآن. حُفظت نسخة pending في $pending_file"
      printf '%s failed credential recovery to %s via %s:%s\n' "$(date -Iseconds)" "$recipient" "$smtp_host" "$smtp_port" >> "$audit_log"
    fi
  else
    cp "$mail_file" "$pending_file"
    echo "SMTP غير مضبوط. حُفظت بيانات الدخول في $recovery_file ونسخة بريد pending في $pending_file"
  fi
}

[ "$(id -u)" = "0" ] || die "يجب تشغيل startup.sh كـ root."
[ -d "$STACK_DIR" ] || die "مجلد compose غير موجود: $STACK_DIR"

# ── Bundle-readiness gate ─────────────────────────────────────────────────────
# Refuse to start if the offline bundle was never baked and we're not online.
if [ "$ALLOW_ONLINE_PULL" != "YES" ] && [ ! -f "$BUNDLE_READY" ]; then
  die "الحزمة المحلية غير مُعدَّة. شغّل build-offline-bundle.sh على جهاز متصل أولاً، أو مرر CARBONFLOW_ALLOW_ONLINE_PULL=YES لاستخدام الإنترنت."
fi

if [ -f "$RUNTIME_ENV" ]; then
  . "$RUNTIME_ENV"
  DOCKER_DATA_ROOT="${CARBONFLOW_DOCKER_DATA_ROOT:-$DOCKER_DATA_ROOT}"
  ALLOW_ONLINE_PULL="${CARBONFLOW_ALLOW_ONLINE_PULL:-$ALLOW_ONLINE_PULL}"
  RUNTIME_ZRAM_MB="${CARBONFLOW_ZRAM_MB:-$RUNTIME_ZRAM_MB}"
fi

if [ -f "$HARDWARE_ENV" ]; then
  . "$HARDWARE_ENV"
else
  mkdir -p /etc/carbonflow
  CARBONFLOW_DISK_NAME="$(lsblk -dn -o NAME | head -n 1)"
  CARBONFLOW_DISK_TYPE="hdd"
  CARBONFLOW_ZRAM_MB="16384"
  cat > "$HARDWARE_ENV" <<EOF
CARBONFLOW_DISK_NAME="$CARBONFLOW_DISK_NAME"
CARBONFLOW_DISK_TYPE="$CARBONFLOW_DISK_TYPE"
CARBONFLOW_ZRAM_MB="$CARBONFLOW_ZRAM_MB"
EOF
fi
if [ -n "$RUNTIME_ZRAM_MB" ]; then
  CARBONFLOW_ZRAM_MB="$RUNTIME_ZRAM_MB"
fi

echo "==> تفعيل مستودعات community وتحديث الحزم"
sed -i 's/^#\(.*\/community\)$/\1/' /etc/apk/repositories || true

# carbonflow: prefer local offline APK repository copied from the deployment bundle
if [ -f /opt/carbonflow/apks/x86_64/APKINDEX.tar.gz ]; then
  printf '%s\n' /opt/carbonflow/apks > /etc/apk/repositories
fi
apk update --allow-untrusted || apk update
apk add --no-cache --allow-untrusted \
  bash curl jq git openssl ca-certificates tzdata \
  docker docker-cli-compose zram-init htop \
  iptables ip6tables logrotate shadow util-linux doas wpa_supplicant iw
apk add --no-cache --allow-untrusted ctop || echo "ctop غير متاح في مستودعات Alpine الحالية؛ يمكن تثبيته لاحقاً كأداة اختيارية."

mkdir -p /etc/doas.d
echo "permit persist :wheel" > /etc/doas.d/carbonflow-wheel.conf
chmod 600 /etc/doas.d/carbonflow-wheel.conf

echo "==> ضبط timezone"
cp /usr/share/zoneinfo/Asia/Riyadh /etc/localtime
echo "Asia/Riyadh" > /etc/timezone

echo "==> ضبط chrony على sa.pool.ntp.org لدقة سجلات المجمعة"
cat > /etc/chrony/chrony.conf <<'EOF'
pool sa.pool.ntp.org iburst
pool 2.alpine.pool.ntp.org iburst
driftfile /var/lib/chrony/chrony.drift
makestep 1.0 3
rtcsync
logdir /var/log/chrony
EOF
rc-update add chronyd default
rc-service chronyd restart || rc-service chronyd start || true

echo "==> ضبط ZRAM: ${CARBONFLOW_ZRAM_MB}MB swap مضغوط داخل الذاكرة"
cat > /etc/conf.d/zram-init <<EOF
load_on_start=yes
unload_on_stop=yes
num_devices=1
type0=swap
size0=$CARBONFLOW_ZRAM_MB
EOF

cat > /etc/sysctl.d/99-carbonflow-memory.conf <<'EOF'
vm.swappiness=100
vm.page-cluster=0
vm.vfs_cache_pressure=80
vm.dirty_background_ratio=3
vm.dirty_ratio=10
EOF

rc-update add zram-init default
rc-service zram-init restart || rc-service zram-init start
sysctl --system || true

echo "==> تطبيق تحسينات I/O حسب نوع القرص: $CARBONFLOW_DISK_TYPE"
cat > /usr/local/sbin/carbonflow-disk-tune <<'EOF'
#!/bin/sh
set -eu
. /etc/carbonflow/hardware.env
queue="/sys/block/$CARBONFLOW_DISK_NAME/queue"
[ -d "$queue" ] || exit 0

if [ "$CARBONFLOW_DISK_TYPE" = "ssd" ]; then
  echo 0 > "$queue/rotational" 2>/dev/null || true
  echo 256 > "$queue/read_ahead_kb" 2>/dev/null || true
  if [ -f "$queue/scheduler" ]; then
    grep -q "none" "$queue/scheduler" && echo none > "$queue/scheduler" 2>/dev/null || true
  fi
else
  echo 4096 > "$queue/read_ahead_kb" 2>/dev/null || true
  if [ -f "$queue/scheduler" ]; then
    grep -q "mq-deadline" "$queue/scheduler" && echo mq-deadline > "$queue/scheduler" 2>/dev/null || true
  fi
fi
EOF
chmod +x /usr/local/sbin/carbonflow-disk-tune
/usr/local/sbin/carbonflow-disk-tune || true

cat > /etc/local.d/carbonflow-disk-tune.start <<'EOF'
#!/bin/sh
/usr/local/sbin/carbonflow-disk-tune || true
EOF
chmod +x /etc/local.d/carbonflow-disk-tune.start
rc-update add local default

if [ "${CARBONFLOW_DISK_TYPE:-hdd}" = "ssd" ]; then
  echo "==> تفعيل TRIM أسبوعي للـ SSD"
  rc-update add crond default
  rc-service crond start || true
  cat > /etc/periodic/weekly/carbonflow-fstrim <<'EOF'
#!/bin/sh
fstrim -av || true
EOF
  chmod +x /etc/periodic/weekly/carbonflow-fstrim
fi

echo "==> إعداد Docker بتسجيل محدود لتقليل I/O على HDD"
mkdir -p /etc/docker
mkdir -p "$DOCKER_DATA_ROOT"
cat > /etc/docker/daemon.json <<EOF
{
  "data-root": "$DOCKER_DATA_ROOT",
  "storage-driver": "overlay2",
  "live-restore": true,
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  },
  "icc": false,
  "userland-proxy": false
}
EOF

rc-update add docker default
rc-service docker restart || rc-service docker start

echo "==> تحميل صور Docker من الحزمة المحلية"
if [ -f "$IMAGE_ARCHIVE" ]; then
  echo "  استيراد: $IMAGE_ARCHIVE"
  gzip -dc "$IMAGE_ARCHIVE" | docker load || echo "  تحذير: فشل تحميل بعض الصور من الحزمة."
elif ls "$IMAGE_ARCHIVE".part-* >/dev/null 2>&1; then
  echo "  استيراد أرشيف Docker المقسم: $IMAGE_ARCHIVE.part-*"
  cat "$IMAGE_ARCHIVE".part-* | gzip -dc | docker load \
    || echo "  تحذير: فشل تحميل بعض الصور من الحزمة المقسمة."
else
  echo "  لم يُعثر على $IMAGE_ARCHIVE — سيتم الاعتماد على docker compose pull."
fi

echo "==> استيراد نموذج Ollama من الحزمة المحلية"
if [ -f "$MODEL_ARCHIVE" ]; then
  mkdir -p "$VAULT_DIR/ollama"
  tar -xzf "$MODEL_ARCHIVE" -C "$VAULT_DIR/ollama/" \
    && echo "  Ollama model cache استُعيد من $MODEL_ARCHIVE" \
    || echo "  تحذير: فشل فك ضغط Ollama model archive."
else
  echo "  لم يُعثر على $MODEL_ARCHIVE — سيُنزَّل النموذج عبر الإنترنت إن سُمح."
fi

echo "==> إنشاء Vault وسجلات التطبيقات"
mkdir -p "$LOG_DIR" "$VAULT_DIR/backups" "$VAULT_DIR/products" "$VAULT_DIR/litecart" "$VAULT_DIR/n8n" "$VAULT_DIR/ollama"
mkdir -p "$VAULT_DIR/mail" "$VAULT_DIR/releases" "$VAULT_DIR/reports" "$VAULT_DIR/credentials"
chmod 755 "$VAULT_DIR"
chmod 750 "$LOG_DIR" "$VAULT_DIR/backups" "$VAULT_DIR/products" "$VAULT_DIR/credentials"
chmod 770 "$VAULT_DIR/n8n" "$VAULT_DIR/ollama" "$VAULT_DIR/litecart" "$VAULT_DIR/mail" "$VAULT_DIR/releases" "$VAULT_DIR/reports"
chown -R 1000:1000 "$LOG_DIR" "$VAULT_DIR/n8n" "$VAULT_DIR/products" "$VAULT_DIR/mail" "$VAULT_DIR/releases" "$VAULT_DIR/reports"
chmod 770 "$LOG_DIR"

echo "==> تجهيز ملف البيئة إذا لم يكن موجوداً"
if [ ! -f "$STACK_DIR/.env" ]; then
  cp "$STACK_DIR/.env.example" "$STACK_DIR/.env"
  chmod 600 "$STACK_DIR/.env"
  echo "تم إنشاء $STACK_DIR/.env. عدله بالقيم الحقيقية قبل فتح Cloudflare أو الدفع."
fi
ensure_secret NPM_DB_PASSWORD
ensure_secret NPM_DB_ROOT_PASSWORD
ensure_secret LITECART_DB_PASSWORD
ensure_secret LITECART_DB_ROOT_PASSWORD
ensure_secret N8N_ENCRYPTION_KEY
ensure_secret N8N_BASIC_AUTH_PASSWORD
ensure_secret TELEMETRY_TOKEN
ensure_secret CONTROL_PANEL_PASSWORD
ensure_secret RELEASE_WEBHOOK_SECRET
ensure_secret RELEASE_API_TOKEN
ensure_secret BACKUP_ENCRYPTION_KEY
if [ -z "$(env_value CREDENTIAL_RECOVERY_EMAIL)" ]; then
  set_env_value CREDENTIAL_RECOVERY_EMAIL "far7an.o88@gmail.com"
fi
if [ -z "$(env_value SYSTEM_EMAIL)" ]; then
  set_env_value SYSTEM_EMAIL "info@carbonflow.care"
fi
if [ -z "$(env_value SMTP_HOST)" ]; then
  set_env_value SMTP_HOST "mail.carbonflow.care"
fi
if [ -z "$(env_value SMTP_PORT)" ]; then
  set_env_value SMTP_PORT "587"
fi
if [ -z "$(env_value SMTP_TLS)" ]; then
  set_env_value SMTP_TLS "YES"
fi
if [ -z "$(env_value SMTP_USER)" ]; then
  set_env_value SMTP_USER "info@carbonflow.care"
fi
if [ -z "$(env_value SMTP_PASSWORD)" ]; then
  set_env_value SMTP_PASSWORD "123456!"
fi
if [ -z "$(env_value SMTP_FROM)" ]; then
  set_env_value SMTP_FROM "CarbonFlow Tech <info@carbonflow.care>"
fi
write_credentials_recovery

MODEL="$(awk -F= '/^OLLAMA_MODEL=/ { print $2; found=1 } END { if (!found) print "phi3:mini" }' "$STACK_DIR/.env")"

echo "==> جدولة النسخ الاحتياطي اليومي المشفر"
chmod +x /opt/carbonflow/scripts/cron-backup.sh || true
rc-update add crond default
rc-service crond start || true
cat > /etc/periodic/daily/carbonflow-backup <<'EOF'
#!/bin/sh
/opt/carbonflow/scripts/cron-backup.sh >> /var/log/carbonflow-backup.log 2>&1
EOF
chmod +x /etc/periodic/daily/carbonflow-backup

echo "==> تشغيل stack"
cd "$STACK_DIR"
if [ "$ALLOW_ONLINE_PULL" = "YES" ]; then
  docker compose pull --ignore-buildable || docker compose pull || echo "docker compose pull لم يكتمل بالكامل؛ سيتم الاعتماد على build/up للمتابعة."
  docker compose up -d --build
else
  docker compose up -d --no-build || die "فشل تشغيل Docker Compose من الصور المحلية. جهز docker-images عبر usb/build-offline-bundle.sh أو شغل CARBONFLOW_ALLOW_ONLINE_PULL=YES."
fi

if [ "$ALLOW_ONLINE_PULL" = "YES" ]; then
  echo "==> تنزيل نموذج Ollama المحلي: $MODEL"
  tries=0
  until docker compose exec -T ollama ollama list >/dev/null 2>&1; do
    tries=$((tries + 1))
    [ "$tries" -lt 30 ] || die "Ollama لم يصبح جاهزاً."
    sleep 4
  done
  docker compose exec -T ollama ollama pull "$MODEL"
else
  echo "تم تخطي تنزيل نموذج Ollama لأن التشغيل مضبوط على offline. استخدم ollama-models/ollama-models.tar.gz."
fi

echo "==> محاولة استيراد workflows إلى n8n إن كان جاهزاً"
if docker compose exec -T n8n n8n --version >/dev/null 2>&1; then
  docker compose exec -T n8n /bin/sh -c 'for wf in /workflows/*.json; do [ -f "$wf" ] && n8n import:workflow --input="$wf" || true; done'
fi

echo "==> تشغيل فحص Cloudflare edge عند توفر token حقيقي"
CF_TOKEN_CURRENT="$(env_value CLOUDFLARED_TOKEN)"
if [ -n "$CF_TOKEN_CURRENT" ] && [ "$CF_TOKEN_CURRENT" != "replace_with_cloudflare_tunnel_token" ]; then
  sh /opt/carbonflow/scripts/validate-edge.sh || echo "Edge validation لم يكتمل. راجع Cloudflare/NPM ثم أعد الفحص من لوحة التحكم."
else
  echo "Cloudflare token غير مضبوط بعد. افتح لوحة التحكم على http://SERVER_LAN_IP:8088 لإدخاله ثم شغل الفحص."
fi

echo "==> CarbonFlow Tech جاهز. راجع: docker compose ps"
