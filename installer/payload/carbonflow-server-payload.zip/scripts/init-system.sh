#!/bin/sh
# init-system.sh — CarbonFlow ZTP v3.2 Unified Entry Point
# Invoked by the `carbon` CLI. Runs all pre-flight gates, then delegates
# full disk provisioning to alpine/install-unattended.sh.
#
# Gate order:
#   1. Root check
#   2. Bundle-readiness marker (.bundle-ready)
#   3. APK repository integrity
#   4. Deployment-state marker on CF_ROOT (FORCE_RESET override)
#   5. Target-disk safety checks
#   6. Handoff → install-unattended.sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
KIT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)"
INSTALL_SCRIPT="$SCRIPT_DIR/../alpine/install-unattended.sh"
AUDIT_LIB="$SCRIPT_DIR/lib/hardware-audit.sh"
BUNDLE_READY="$KIT_DIR/.bundle-ready"
INSTALLED_MARKER=".carbonflow-installed"

FORCE_RESET="${FORCE_RESET:-NO}"
LOG_FILE="${CARBONFLOW_LOG_FILE:-/var/log/carbonflow-init-system.log}"
VERSION="3.2"

mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true
exec >>"$LOG_FILE" 2>&1

log()   { printf '%s %s\n' "$(date -Iseconds 2>/dev/null || date)" "$*"; }
die()   { log "FATAL: $*"; echo "FATAL: $*" >&2; exit 1; }
warn()  { log "WARN: $*"; }
info()  { log "==> $*"; }
banner(){ printf '\n%s\n  %s\n%s\n' "$(printf '═%.0s' $(seq 1 58))" "$*" "$(printf '═%.0s' $(seq 1 58))"; }

find_boot_disk() {
  boot_part="$(findfs LABEL=CFBOOT 2>/dev/null || findfs LABEL=CFS 2>/dev/null || true)"
  [ -n "$boot_part" ] || return 0
  boot_name="$(lsblk -no PKNAME "$boot_part" 2>/dev/null | head -n1 || true)"
  [ -n "$boot_name" ] && printf '/dev/%s\n' "$boot_name"
}

is_internal_disk() {
  disk="$1"
  [ -b "$disk" ] || return 1

  boot_disk="$(find_boot_disk)"
  [ -z "$boot_disk" ] || [ "$disk" != "$boot_disk" ] || return 1

  disk_type="$(lsblk -dn -o TYPE "$disk" 2>/dev/null | tr -d ' ' || true)"
  tran="$(lsblk -dn -o TRAN "$disk" 2>/dev/null | tr -d ' ' || true)"
  removable="$(lsblk -dn -o RM "$disk" 2>/dev/null | tr -d ' ' || true)"
  readonly="$(lsblk -dn -o RO "$disk" 2>/dev/null | tr -d ' ' || true)"

  [ "$disk_type" = "disk" ] || return 1
  [ "$tran" != "usb" ] || return 1
  [ "$removable" != "1" ] || return 1
  [ "$readonly" != "1" ] || return 1
  return 0
}

detect_target_disk() {
  if [ -n "${CARBONFLOW_TARGET_DISK:-}" ]; then
    printf '%s\n' "$CARBONFLOW_TARGET_DISK"
    return 0
  fi

  if is_internal_disk /dev/sdd; then
    printf '%s\n' /dev/sdd
    return 0
  fi

  lsblk -dn -o NAME,TYPE 2>/dev/null | while read -r name disk_type; do
    candidate="/dev/$name"
    [ "$disk_type" = "disk" ] || continue
    if is_internal_disk "$candidate"; then
      printf '%s\n' "$candidate"
      break
    fi
  done
}

TARGET_DISK="$(detect_target_disk | head -n1)"
[ -n "$TARGET_DISK" ] || die "No internal target disk found. Set CARBONFLOW_TARGET_DISK=/dev/sdX to override."

log "==> CarbonFlow init-system v$VERSION started"
log "Kit: $KIT_DIR"
log "Target: $TARGET_DISK"

# ── Gate 1: root ──────────────────────────────────────────────────────────────
[ "$(id -u)" = "0" ] || die "يجب تشغيل carbon/init-system كـ root."

# ── Gate 2: Bundle-readiness (.bundle-ready) ──────────────────────────────────
info "Bundle gate"
if [ ! -f "$BUNDLE_READY" ]; then
  banner "ABORT: Offline bundle has not been baked yet."
  cat >&2 <<'EOF'

  The deployment kit requires a pre-baked offline bundle.
  On a connected machine (Alpine/Linux with Docker), run:

    sh usb/build-offline-bundle.sh

  Then re-burn the USB and retry.

EOF
  exit 1
fi
BUNDLE_DATE="$(grep -m1 bundle_date "$BUNDLE_READY" 2>/dev/null | cut -d= -f2 || echo 'unknown')"
info "Bundle ready — baked: $BUNDLE_DATE"

# ── Gate 3: APK repository integrity ─────────────────────────────────────────
info "APK repo integrity"
APK_INDEX=""
for candidate in "$KIT_DIR/../apks/x86_64/APKINDEX.tar.gz" "/media/"*"/apks/x86_64/APKINDEX.tar.gz"; do
  [ -f "$candidate" ] && { APK_INDEX="$candidate"; break; }
done
if [ -z "$APK_INDEX" ]; then
  die "Offline APK repository not found (apks/x86_64/APKINDEX.tar.gz). Run build-offline-bundle.sh first."
fi
gzip -t "$APK_INDEX" || die "Corrupt APKINDEX.tar.gz: $APK_INDEX"
log "APK index OK: $APK_INDEX"

# ── Gate 4: Deployment-state marker ──────────────────────────────────────────
info "Deployment-state marker check on CF_ROOT"
EXISTING_ROOT="$(blkid -L CF_ROOT 2>/dev/null || true)"
if [ -n "$EXISTING_ROOT" ]; then
  TMP_MNT="$(mktemp -d)"
  MNT_OK=0
  mount -o ro "$EXISTING_ROOT" "$TMP_MNT" 2>/dev/null && MNT_OK=1 || true
  if [ "$MNT_OK" = "1" ] && [ -f "$TMP_MNT/$INSTALLED_MARKER" ]; then
    TS="$(cat "$TMP_MNT/$INSTALLED_MARKER" 2>/dev/null || echo 'unknown')"
    umount "$TMP_MNT" 2>/dev/null || true; rmdir "$TMP_MNT" 2>/dev/null || true
    if [ "$FORCE_RESET" != "YES" ]; then
      banner "CarbonFlow is ALREADY INSTALLED — data protected."
      cat >&2 <<EOF

  Installed : $TS
  Partition : $EXISTING_ROOT
  Marker    : /$INSTALLED_MARKER

  This guard prevents accidental data destruction.
  To force a complete reinstall use:

    FORCE_RESET=YES carbon

EOF
      exit 3
    fi
    warn "FORCE_RESET=YES — proceeding. Existing data WILL be destroyed."
  else
    umount "$TMP_MNT" 2>/dev/null || true; rmdir "$TMP_MNT" 2>/dev/null || true
    log "No prior installation marker on $EXISTING_ROOT."
  fi
else
  log "CF_ROOT label not found — fresh disk assumed."
fi

# ── Gate 5: Target-disk safety ────────────────────────────────────────────────
info "Target-disk safety: $TARGET_DISK"
[ -b "$TARGET_DISK" ] || {
  echo ""
  echo "Available disks:"
  lsblk -dn -o NAME,SIZE,TYPE,TRAN,MODEL 2>/dev/null || true
  die "Target disk not found: $TARGET_DISK"
}

# Refuse to wipe the USB we booted from
BOOT_PART="$(findfs LABEL=CFBOOT 2>/dev/null || findfs LABEL=CFS 2>/dev/null || true)"
if [ -n "$BOOT_PART" ]; then
  BOOT_DISK="$(lsblk -no PKNAME "$BOOT_PART" 2>/dev/null | head -n1 || true)"
  BOOT_DISK="${BOOT_DISK:+/dev/$BOOT_DISK}"
  [ "$TARGET_DISK" != "$BOOT_DISK" ] \
    || die "Refusing to wipe the boot USB: $TARGET_DISK — choose a different disk."
fi

# Refuse to wipe removable/USB media
TRAN="$(lsblk -dn -o TRAN "$TARGET_DISK" 2>/dev/null | tr -d ' ' || true)"
RM="$(lsblk -dn -o RM "$TARGET_DISK" 2>/dev/null | tr -d ' ' || true)"
if [ "$TRAN" = "usb" ] || [ "$RM" = "1" ]; then
  die "Refusing to wipe removable/USB disk: $TARGET_DISK"
fi

DISK_SIZE="$(lsblk -dn -o SIZE "$TARGET_DISK" 2>/dev/null | awk '{print $1}')"
info "Disk validated: $TARGET_DISK ($DISK_SIZE)"

# ── Pre-flight summary ────────────────────────────────────────────────────────
banner "Pre-flight PASSED — starting installation"
log "  Target disk  : $TARGET_DISK  ($DISK_SIZE)"
log "  Partition    : MBR/dos — ROOT(1,20G,bootable) SWAP(2,27648M) VAULT(3)"
log "  Boot loader  : GRUB i386-pc → MBR"
log "  ZRAM         : 27,648 MB"
log "  WiFi SSID    : HOUSE4G"
log "  FORCE_RESET  : $FORCE_RESET"
log "  Bundle date  : $BUNDLE_DATE"

# ── Handoff to install-unattended.sh ──────────────────────────────────────────
info "Delegating to install-unattended.sh"
[ -f "$INSTALL_SCRIPT" ] || die "install-unattended.sh not found: $INSTALL_SCRIPT"

CARBONFLOW_WIPE=YES \
CARBONFLOW_TARGET_DISK="$TARGET_DISK" \
FORCE_RESET="$FORCE_RESET" \
  sh "$INSTALL_SCRIPT" "$TARGET_DISK"

log "==> init-system v$VERSION completed."
