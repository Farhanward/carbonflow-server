#!/bin/sh
set -u

VERSION="1.0"
LOG_FILE="${CARBONFLOW_AGENT_LOG:-/var/log/carbonflow-agent.log}"

mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true

log() {
  printf '%s %s\n' "$(date -Iseconds 2>/dev/null || date)" "$*" >> "$LOG_FILE"
}

say() {
  printf '%s\n' "$*"
  log "$*"
}

find_kit_dir() {
  script_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
  candidate="$(CDPATH= cd -- "$script_dir/.." && pwd)"
  [ -f "$candidate/scripts/init-system.sh" ] && {
    echo "$candidate"
    return 0
  }

  for dir in /opt/carbonflow /mnt/carbonflow-data/opt/carbonflow /media/*/carbonflow-usb-deployment /mnt/*/carbonflow-usb-deployment /carbonflow-usb-deployment; do
    [ -f "$dir/scripts/init-system.sh" ] && {
      echo "$dir"
      return 0
    }
  done
  return 1
}

remount_exec_for_path() {
  path="$1"
  best=""
  while read -r _ mountpoint _ _ _; do
    case "$path" in
      "$mountpoint"|"$mountpoint"/*)
        if [ "${#mountpoint}" -gt "${#best}" ]; then
          best="$mountpoint"
        fi
        ;;
    esac
  done < /proc/mounts

  [ -n "$best" ] || return 0
  mount -o remount,exec "$best" 2>/dev/null || true
}

json_escape() {
  sed 's/\\/\\\\/g; s/"/\\"/g; s/$/\\n/' | tr -d '\n'
}

load_agent_env() {
  for env_file in "$KIT_DIR/config/agent.env" "$KIT_DIR/config/agent.env.example" /root/.carbonflow-agent.env; do
    [ -f "$env_file" ] || continue
    # shellcheck disable=SC1090
    . "$env_file"
    [ "$env_file" = "$KIT_DIR/config/agent.env.example" ] || break
  done
}

collect_diagnostics() {
  out="${1:-/tmp/carbonflow-agent-diagnostics.txt}"
  {
    echo "CarbonFlow diagnostics"
    date -Iseconds 2>/dev/null || date
    echo
    echo "== lsblk =="
    lsblk -o NAME,SIZE,TYPE,FSTYPE,LABEL,TRAN,ROTA,MOUNTPOINTS 2>&1 || true
    echo
    echo "== ip =="
    ip addr 2>&1 || true
    ip route 2>&1 || true
    echo
    echo "== docker =="
    docker ps -a 2>&1 || true
    echo
    echo "== recent init log =="
    tail -n 200 /var/log/carbonflow-init-system.log 2>&1 || true
  } > "$out"
  echo "$out"
}

call_openai_bridge() {
  diag_file="$1"
  [ -n "${OPENAI_API_KEY:-}" ] || {
    say "OpenAI token is missing. Put it in $KIT_DIR/config/agent.env as OPENAI_API_KEY."
    return 0
  }

  prompt="$(head -c 12000 "$diag_file" | json_escape)"
  payload="/tmp/carbonflow-openai-request.json"
  cat > "$payload" <<EOF
{"model":"${OPENAI_MODEL:-gpt-4o}","messages":[{"role":"system","content":"You are the CarbonFlow field installer supervisor. Diagnose the deployment failure from sanitized logs. Do not request secrets. Return concise repair steps."},{"role":"user","content":"$prompt"}],"temperature":0.1}
EOF
  say "Calling ChatGPT bridge for diagnostics..."
  curl -fsS --max-time 120 "$OPENAI_API_URL" \
    -H "Authorization: Bearer $OPENAI_API_KEY" \
    -H "Content-Type: application/json" \
    -d @"$payload" > /tmp/carbonflow-openai-response.json \
    && cat /tmp/carbonflow-openai-response.json \
    || say "ChatGPT bridge call failed; raw diagnostics remain at $diag_file."
}

call_anthropic_bridge() {
  diag_file="$1"
  [ -n "${ANTHROPIC_API_KEY:-}" ] || {
    say "Claude token is missing. Put it in $KIT_DIR/config/agent.env as ANTHROPIC_API_KEY."
    return 0
  }
  [ -n "${ANTHROPIC_MODEL:-}" ] || {
    say "Claude model is not set. Put ANTHROPIC_MODEL in $KIT_DIR/config/agent.env."
    return 0
  }

  prompt="$(head -c 12000 "$diag_file" | json_escape)"
  payload="/tmp/carbonflow-anthropic-request.json"
  cat > "$payload" <<EOF
{"model":"${ANTHROPIC_MODEL}","max_tokens":1200,"messages":[{"role":"user","content":"You are the CarbonFlow field installer supervisor. Diagnose this deployment failure from sanitized logs. Do not request secrets. Return concise repair steps.\\n\\n$prompt"}]}
EOF
  say "Calling Claude bridge for diagnostics..."
  curl -fsS --max-time 120 "$ANTHROPIC_API_URL" \
    -H "x-api-key: $ANTHROPIC_API_KEY" \
    -H "anthropic-version: ${ANTHROPIC_VERSION:-2023-06-01}" \
    -H "Content-Type: application/json" \
    -d @"$payload" > /tmp/carbonflow-anthropic-response.json \
    && cat /tmp/carbonflow-anthropic-response.json \
    || say "Claude bridge call failed; raw diagnostics remain at $diag_file."
}

run_installer() {
  provider="$1"
  export CARBONFLOW_AGENT_PROVIDER="$provider"
  export FORCE_RESET="${FORCE_RESET:-${CARBONFLOW_FORCE_RESET:-NO}}"

  say "Provider selected: $provider"
  say "Target disk: ${CARBONFLOW_TARGET_DISK:-auto-detect internal disk, prefer /dev/sdd}"
  say "Force reset: $FORCE_RESET"
  say "Starting deterministic CarbonFlow installer through sh..."

  set +e
  sh "$KIT_DIR/scripts/init-system.sh"
  rc="$?"
  set -u

  if [ "$rc" = "0" ]; then
    say "CarbonFlow installation completed successfully."
    return 0
  fi

  say "Installer failed with exit code $rc. Collecting diagnostics..."
  diag_file="$(collect_diagnostics)"
  case "$provider" in
    openai) call_openai_bridge "$diag_file" ;;
    anthropic) call_anthropic_bridge "$diag_file" ;;
    offline) say "Offline diagnostics saved at: $diag_file" ;;
  esac
  return "$rc"
}

show_menu() {
  clear 2>/dev/null || true
  cat <<'EOF'
========================================
 CarbonFlow Agent Installer
========================================
Choose who supervises the installation:

  1 - ChatGPT
  2 - Claude
  3 - Offline local mode

EOF
  printf "Selection [1/2/3]: "
}

KIT_DIR="$(find_kit_dir)" || {
  echo "ERROR: CarbonFlow deployment kit was not found." >&2
  exit 1
}
remount_exec_for_path "$KIT_DIR"
load_agent_env

log "CarbonFlow Agent Installer v$VERSION started from $KIT_DIR"

if [ "${1:-}" = "--openai" ]; then
  run_installer openai
  exit $?
fi
if [ "${1:-}" = "--claude" ]; then
  run_installer anthropic
  exit $?
fi
if [ "${1:-}" = "--offline" ]; then
  run_installer offline
  exit $?
fi

show_menu
read -r choice
case "$choice" in
  1) run_installer openai ;;
  2) run_installer anthropic ;;
  3) run_installer offline ;;
  *) say "Invalid selection. Nothing was installed."; exit 2 ;;
esac
