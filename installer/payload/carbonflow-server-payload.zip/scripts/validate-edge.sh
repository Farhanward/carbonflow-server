#!/bin/sh
set -eu

STACK_DIR="${STACK_DIR:-/opt/carbonflow/compose}"
ENV_FILE="$STACK_DIR/.env"
DOMAIN_DEFAULT="carbonflows.store"

get_env() {
  key="$1"
  awk -F= -v k="$key" '$1 == k { sub(/^[^=]*=/, ""); print; found=1 } END { if (!found) print "" }' "$ENV_FILE"
}

fail() {
  echo "FAIL: $*" >&2
  exit 1
}

[ -f "$ENV_FILE" ] || fail "ملف البيئة غير موجود: $ENV_FILE"

DOMAIN="$(get_env DOMAIN)"
CLOUDFLARED_TOKEN="$(get_env CLOUDFLARED_TOKEN)"
CF_API_TOKEN="$(get_env CF_API_TOKEN)"
CF_ZONE_ID="$(get_env CF_ZONE_ID)"
DOMAIN="${DOMAIN:-$DOMAIN_DEFAULT}"

case "$CLOUDFLARED_TOKEN" in
  ""|replace_with_cloudflare_tunnel_token) fail "CLOUDFLARED_TOKEN غير مضبوط." ;;
esac

cd "$STACK_DIR"

echo "==> فحص اتصال Cloudflare Tunnel"
if ! docker compose ps cloudflared | grep -qi "running"; then
  fail "حاوية cloudflared ليست في حالة running."
fi

if ! docker compose logs --tail=200 cloudflared | grep -Eiq "Registered tunnel connection|Connection registered|Connected"; then
  fail "لم أجد في سجلات cloudflared دليلاً على اتصال tunnel ناجح."
fi

echo "==> فحص HTTPS وCloudflare edge headers"
for host in "$DOMAIN" "www.$DOMAIN" "n8n.$DOMAIN"; do
  echo "-- $host"
  headers="$(curl -fsSI --max-time 20 "https://$host" || true)"
  echo "$headers" | grep -qi '^server: cloudflare' || fail "$host لا يبدو أنه يمر عبر Cloudflare."
  echo "$headers" | grep -qi '^cf-ray:' || fail "$host لا يعيد CF-Ray header."
  echo "$headers" | awk 'BEGIN{IGNORECASE=1}/^(cf-cache-status|cf-ray|server):/ {print "  " $0}'
done

echo "==> Tiered cache warmup/check لمنطق مناطق Middle East / Europe / Americas"
for region in middle-east europe americas; do
  url="https://$DOMAIN/?carbonflow_cache_probe=$region"
  curl -fsS --max-time 20 -o /dev/null "$url" || fail "فشل warmup للمنطقة المنطقية: $region"
  headers="$(curl -fsSI --max-time 20 "$url" || true)"
  echo "-- $region"
  echo "$headers" | grep -qi '^cf-ray:' || fail "لا يوجد CF-Ray في probe: $region"
  echo "$headers" | awk 'BEGIN{IGNORECASE=1}/^(cf-cache-status|cache-control|cf-ray):/ {print "  " $0}'
done

echo "==> فحص Tiered Caching عبر Cloudflare API إن توفرت الصلاحيات"
if [ -n "$CF_API_TOKEN" ] && [ -n "$CF_ZONE_ID" ]; then
  smart="$(curl -fsS "https://api.cloudflare.com/client/v4/zones/$CF_ZONE_ID/cache/tiered_cache_smart_topology_enable" \
    -H "Authorization: Bearer $CF_API_TOKEN" \
    -H "Content-Type: application/json" || true)"
  regional="$(curl -fsS "https://api.cloudflare.com/client/v4/zones/$CF_ZONE_ID/cache/regional_tiered_cache" \
    -H "Authorization: Bearer $CF_API_TOKEN" \
    -H "Content-Type: application/json" || true)"
  echo "$smart" | grep -q '"success":true' || fail "تعذر قراءة Smart Tiered Cache من Cloudflare API."
  echo "$regional" | grep -q '"success":true' || fail "تعذر قراءة Regional Tiered Cache من Cloudflare API."
  echo "Smart Tiered Cache: $(echo "$smart" | jq -r '.result.value // .result' 2>/dev/null || echo checked)"
  echo "Regional Tiered Cache: $(echo "$regional" | jq -r '.result.value // .result' 2>/dev/null || echo checked)"
else
  echo "تم تخطي فحص API لأن CF_API_TOKEN أو CF_ZONE_ID غير مضبوط. فحص headers المحلي نجح."
fi

echo "==> Edge validation passed"
