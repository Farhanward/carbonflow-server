#!/bin/sh
set -eu

STACK_DIR="${STACK_DIR:-/opt/carbonflow/compose}"
VAULT_DIR="${VAULT_DIR:-/vault}"
BACKUP_ROOT="$VAULT_DIR/backups"
DATE="$(date -u +%Y%m%dT%H%M%SZ)"
WORK_DIR="$BACKUP_ROOT/work-$DATE"
ARCHIVE="$BACKUP_ROOT/carbonflow-backup-$DATE.tar.gz"
ENCRYPTED="$ARCHIVE.enc"
RETENTION_DAYS="${BACKUP_RETENTION_DAYS:-14}"

log() {
  echo "[$(date -Iseconds)] $*"
}

env_value() {
  key="$1"
  awk -F= -v k="$key" '$1 == k { sub(/^[^=]*=/, ""); print; found=1 } END { if (!found) print "" }' "$STACK_DIR/.env"
}

find_usb_backup_mount() {
  for label in CFBACKUP CFDATA CFBOOT; do
    dev="$(findfs "LABEL=$label" 2>/dev/null || true)"
    if [ -n "$dev" ]; then
      mountpoint="$(awk -v d="$dev" '$1 == d { print $2; exit }' /proc/mounts)"
      if [ -z "$mountpoint" ]; then
        mountpoint="/media/$label"
        mkdir -p "$mountpoint"
        mount "$dev" "$mountpoint" 2>/dev/null || true
      fi
      [ -d "$mountpoint" ] && echo "$mountpoint" && return 0
    fi
  done
  for dir in /media/* /mnt/*; do
    [ -d "$dir" ] || continue
    [ -w "$dir" ] || continue
    echo "$dir"
    return 0
  done
  return 1
}

mkdir -p "$WORK_DIR" "$BACKUP_ROOT"
chmod 700 "$WORK_DIR"

log "Starting CarbonFlow hybrid backup"
cd "$STACK_DIR"

log "Dump MariaDB databases"
docker compose exec -T npm-db sh -c 'mariadb-dump -uroot -p"$MARIADB_ROOT_PASSWORD" --all-databases' > "$WORK_DIR/npm-db.sql" || true
docker compose exec -T litecart-db sh -c 'mariadb-dump -uroot -p"$MARIADB_ROOT_PASSWORD" --all-databases' > "$WORK_DIR/litecart-db.sql" || true

log "Copy vault data"
mkdir -p "$WORK_DIR/vault"
for item in logs products n8n reports mail; do
  [ -e "$VAULT_DIR/$item" ] && cp -a "$VAULT_DIR/$item" "$WORK_DIR/vault/$item"
done

log "Copy tokens and hardware metadata"
mkdir -p "$WORK_DIR/config"
cp -a "$STACK_DIR/.env" "$WORK_DIR/config/env" 2>/dev/null || true
cp -a /etc/carbonflow "$WORK_DIR/config/carbonflow" 2>/dev/null || true

tar -C "$WORK_DIR" -czf "$ARCHIVE" .
rm -rf "$WORK_DIR"

BACKUP_KEY="$(env_value BACKUP_ENCRYPTION_KEY)"
if [ -z "$BACKUP_KEY" ] || echo "$BACKUP_KEY" | grep -q '^change_me'; then
  BACKUP_KEY="$(env_value CONTROL_PANEL_PASSWORD)"
fi

if [ -z "$BACKUP_KEY" ]; then
  log "No BACKUP_ENCRYPTION_KEY available; refusing to leave unencrypted backup."
  rm -f "$ARCHIVE"
  exit 1
fi

openssl enc -aes-256-cbc -pbkdf2 -salt -in "$ARCHIVE" -out "$ENCRYPTED" -pass "pass:$BACKUP_KEY"
rm -f "$ARCHIVE"
chmod 600 "$ENCRYPTED"

USB_MOUNT="$(find_usb_backup_mount || true)"
if [ -n "$USB_MOUNT" ]; then
  mkdir -p "$USB_MOUNT/carbonflow-backups"
  cp "$ENCRYPTED" "$USB_MOUNT/carbonflow-backups/"
  sync
  log "Encrypted backup copied to $USB_MOUNT/carbonflow-backups"
else
  log "No writable USB backup mount found; backup kept at $ENCRYPTED"
fi

find "$BACKUP_ROOT" -name 'carbonflow-backup-*.tar.gz.enc' -mtime +"$RETENTION_DAYS" -delete 2>/dev/null || true
log "Backup completed: $ENCRYPTED"
